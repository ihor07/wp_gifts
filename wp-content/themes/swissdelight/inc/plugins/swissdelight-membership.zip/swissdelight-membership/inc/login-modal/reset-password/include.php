<?php

include_once SWISSDELIGHT_MEMBERSHIP_LOGIN_MODAL_PATH . '/reset-password/helper.php';