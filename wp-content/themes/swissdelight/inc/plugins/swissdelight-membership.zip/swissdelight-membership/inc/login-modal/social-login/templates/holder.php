<div class="qodef-m-social-login">
	<?php do_action( 'swissdelight_membership_action_social_login_content' ); ?>
</div>