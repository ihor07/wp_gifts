<a href="#" class="qodef-login-opener">
	<span class="qodef-login-opener-text"><?php esc_html_e( 'Login', 'swissdelight-membership' ); ?></span>
    <?php swissdelight_render_svg_icon( 'cart-icon', 'qodef-m-svg-icon' ); ?>
</a>