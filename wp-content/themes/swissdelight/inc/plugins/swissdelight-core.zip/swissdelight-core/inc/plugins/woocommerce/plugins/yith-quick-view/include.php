<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/helper.php';
include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/class-swissdelightcore-woocommerce-yith-quick-view.php';
