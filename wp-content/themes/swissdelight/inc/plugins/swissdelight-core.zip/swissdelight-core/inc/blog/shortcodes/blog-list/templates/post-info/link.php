<a itemprop="url" class="qodef-e-post-link" href="<?php the_permalink(); ?>"></a>
