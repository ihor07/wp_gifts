<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/elementor/class-swissdelightcore-elementor-section-handler.php';
}
