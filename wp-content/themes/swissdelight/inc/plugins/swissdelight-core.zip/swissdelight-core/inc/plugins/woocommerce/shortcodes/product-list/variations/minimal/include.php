<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/minimal/minimal.php';
