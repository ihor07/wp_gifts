<?php

include_once SWISSDELIGHT_CORE_CPT_PATH . '/class-swissdelightcore-custom-post-types.php';
