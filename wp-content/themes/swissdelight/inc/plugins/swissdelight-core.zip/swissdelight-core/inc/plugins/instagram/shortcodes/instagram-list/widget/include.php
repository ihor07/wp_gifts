<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-swissdelightcore-instagram-list-widget.php';
