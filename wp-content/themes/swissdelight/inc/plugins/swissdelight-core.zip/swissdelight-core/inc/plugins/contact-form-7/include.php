<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/contact-form-7/class-swissdelightcore-contact-form-7.php';
