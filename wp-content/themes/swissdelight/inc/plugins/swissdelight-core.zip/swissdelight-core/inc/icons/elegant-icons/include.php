<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/elegant-icons/class-swissdelightcore-elegant-icons-pack.php';
