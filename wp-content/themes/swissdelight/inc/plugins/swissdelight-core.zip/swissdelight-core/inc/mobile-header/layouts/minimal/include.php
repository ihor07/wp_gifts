<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/minimal/helper.php';
include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/minimal/class-swissdelightcore-minimal-mobile-header.php';
include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/admin/minimal-mobile-header-options.php';
