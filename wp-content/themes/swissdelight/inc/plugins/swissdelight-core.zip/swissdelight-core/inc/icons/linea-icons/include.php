<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/linea-icons/class-swissdelightcore-linea-icons-pack.php';
