<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/standard/helper.php';
include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/standard/class-swissdelightcore-standard-mobile-header.php';
include_once SWISSDELIGHT_CORE_INC_PATH . '/mobile-header/layouts/standard/dashboard/admin/standard-mobile-header-options.php';
