<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/timetable/class-swissdelightcore-timetable.php';
