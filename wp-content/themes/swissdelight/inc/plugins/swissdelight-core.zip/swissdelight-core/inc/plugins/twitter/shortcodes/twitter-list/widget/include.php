<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-swissdelightcore-twitter-list-widget.php';
