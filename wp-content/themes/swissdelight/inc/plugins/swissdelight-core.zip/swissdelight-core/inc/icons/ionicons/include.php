<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/ionicons/class-swissdelightcore-ionicons-pack.php';
