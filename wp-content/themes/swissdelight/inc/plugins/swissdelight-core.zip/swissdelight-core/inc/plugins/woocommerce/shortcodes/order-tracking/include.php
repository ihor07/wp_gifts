<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/order-tracking/class-swissdelightcore-order-tracking-shortcode.php';
