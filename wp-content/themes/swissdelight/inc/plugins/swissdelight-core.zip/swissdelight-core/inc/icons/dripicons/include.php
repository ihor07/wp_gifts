<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/dripicons/class-swissdelightcore-dripicons-pack.php';
