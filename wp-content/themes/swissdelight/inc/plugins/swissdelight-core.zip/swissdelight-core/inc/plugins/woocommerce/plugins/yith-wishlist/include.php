<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/helper.php';
include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/class-swissdelightcore-woocommerce-yith-wishlist.php';
