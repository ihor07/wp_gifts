<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/simple/simple.php';
