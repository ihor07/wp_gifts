<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-swissdelightcore-twitter-list-shortcode.php';
