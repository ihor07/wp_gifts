<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/material-icons/class-swissdelightcore-material-icons-pack.php';
