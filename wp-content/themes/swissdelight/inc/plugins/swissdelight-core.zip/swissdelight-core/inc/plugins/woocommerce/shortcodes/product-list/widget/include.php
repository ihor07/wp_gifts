<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/plugins/woocommerce/shortcodes/product-list/widget/class-swissdelightcore-product-list-widget.php';
