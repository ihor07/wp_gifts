<?php

include_once SWISSDELIGHT_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-category-list/variations/gallery/helper.php';
