<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-swissdelightcore-instagram-list-shortcode.php';
