<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-swissdelightcore-woocommerce-dropdown-cart-widget.php';
