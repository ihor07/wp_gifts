<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/font-awesome/class-swissdelightcore-font-awesome-pack.php';
