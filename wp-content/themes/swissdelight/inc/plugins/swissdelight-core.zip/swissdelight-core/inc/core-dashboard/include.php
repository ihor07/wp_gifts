<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/core-dashboard/class-swissdelightcore-dashboard.php';
