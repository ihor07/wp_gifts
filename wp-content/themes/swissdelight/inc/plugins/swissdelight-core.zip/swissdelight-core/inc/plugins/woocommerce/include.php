<?php

include_once SWISSDELIGHT_CORE_PLUGINS_PATH . '/woocommerce/class-swissdelightcore-woocommerce.php';
