<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/simple-line-icons/class-swissdelightcore-simple-line-icons-pack.php';
