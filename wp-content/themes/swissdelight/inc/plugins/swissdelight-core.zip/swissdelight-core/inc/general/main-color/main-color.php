<?php 
$color_selector = array('#qodef-woo-page.qodef--single .woocommerce-Reviews .woocommerce-review__published-date');
