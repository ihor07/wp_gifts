(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.swissdelight_core_product_category_list                    = {};
	qodefCore.shortcodes.swissdelight_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.swissdelight_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
