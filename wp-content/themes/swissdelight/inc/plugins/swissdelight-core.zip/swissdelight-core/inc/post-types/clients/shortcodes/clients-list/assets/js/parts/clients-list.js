(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.swissdelight_core_clients_list             = {};
	qodefCore.shortcodes.swissdelight_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
