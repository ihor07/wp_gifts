<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/core-dashboard/rest/class-swissdelightcore-dashboard-rest-api.php';
