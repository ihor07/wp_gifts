<?php

include_once SWISSDELIGHT_CORE_INC_PATH . '/icons/linear-icons/class-swissdelightcore-linear-icons-pack.php';
